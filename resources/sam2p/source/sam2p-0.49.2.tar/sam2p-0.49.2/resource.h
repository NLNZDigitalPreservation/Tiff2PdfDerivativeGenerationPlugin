//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vcsam2p.rc
//
#define IDC_MYICON                      2
#define IDOK2                           3
#define IDD_VCSAM2P_DIALOG              102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_VCSAM2P                     107
#define IDI_SMALL                       108
#define IDC_VCSAM2P                     109
#define IDR_MAINFRAME                   128
#define IDI_SAM2P16                     131
#define IDI_SAM2P32                     132
#define IDD_RUN                         133
#define IDC_PRODUCT                     1000
#define IDC_EDIT1                       1001
#define IDC_ELOG                        1001
#define IDC_INFO                        1001
#define IDC_EDIT2                       1002
#define IDM_OPEN                        32771
#define IDM_SAVE                        32772
#define IDM_WEBSITE                     32773
#define IDM_SAVE_AS                     32774
#define IDM_NEW                         32775
#define IDM_PARAMETERS                  32776
#define IDC_STATIC                      -1
#define IDC_COPYRIGHT                   -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
