Sejda-console application.

Documentation online
* Available at http://www.sejda.org/shell-interface/

Requirements
* Java Runtime 1.5 (or newer)

Quick install & run
* Extract the downloaded zip file
* (Linux/Mac) Grant execution permissions: > chmod +x bin/sejda-console
* (Linux/Mac) Execute the console: > ./bin/sejda-console
* (Windows) Execute bin/sejda-console.bat

License: Apache License 2.0
Feedbacks to: info@sejda.org
Issue tracker: https://github.com/torakiki/sejda/issues

Note: Application comes with ABSOLUTELY NO WARRANTY
