This folder contains sample files for different inputs of sejda-console.

- Merge tasks accepts a config file (xml, csv formats) that specifies the input files. You can find config samples in this folder, together with an xsd validator for the xml input. 